import headerStyles from '../styles/Header.module.css'

const Header = () => {
  return (
    <>
      <p className={headerStyles.title}>Header</p>
    </>
  )
}

export default Header
